/* Share hub. Anyone can browse AND share; there is no mentor/mentee lock.
 * Data is in localStorage (tfw_posts, tfw_reqs, tfw_saved). Swap load/save for an API when the backend exists. */
(function () {
  const load = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  const me = (() => { try { const s = JSON.parse(localStorage.getItem("tfw_session")); return s && s.email ? s.email.split("@")[0] : "You"; } catch (e) { return "You"; } })();
  const T = "Data & AI › Artificial intelligence › ", S = "Professional Speaking › Speaking with confidence › ";
  const seed = [
    { id: "s1", author: "Priya S.", title: "Intro to AI: a one-page cheat sheet", topic: T + "Intro to AI", vis: "public", cap: 0, body: "The five terms everyone mixes up (model, training, prompt, bias, hallucination) with plain-language examples you can use in a meeting.", link: "" },
    { id: "s2", author: "Dana R.", title: "How to open a talk without freezing", topic: S + "Giving a talk", vis: "public", cap: 0, body: "Three opening lines that work, a breathing routine for the first 30 seconds, and how to recover if you lose your place.", link: "" },
    { id: "s3", author: "Marisol V.", title: "Breaking into tech from another career", topic: "Careers & Digital Skills › Career coaching › Breaking into tech", vis: "one", cap: 2, body: "My full roadmap, resume templates, and the questions I coach career changers through. Shared one-on-one so I can tailor it.", link: "" },
    { id: "s4", author: "Keisha T.", title: "Machine learning basics, step by step", topic: T + "Machine learning basics", vis: "one", cap: 1, body: "A beginner study plan with weekly exercises. I walk through it live with one learner at a time.", link: "" },
  ];
  let posts = load("tfw_posts", null); if (!posts) { posts = seed; save("tfw_posts", posts); }
  let reqs = load("tfw_reqs", []), saved = load("tfw_saved", []);
  const leaf = (t) => t.split(" › ").pop(), cat = (t) => t.split(" › ")[0];
  const leaves = (n, p) => n.flatMap((x) => x.children ? leaves(x.children, p.concat(x.name)) : [p.concat(x.name).join(" › ")]);
  const ALL = leaves(window.TOPIC_TREE || [], []), CATS = [...new Set(ALL.map(cat))];
  const view = document.getElementById("view");
  let q = "", fc = "", toast = "";

  function h(tag, a, ...kids) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(a || {})) {
      if (k === "class") n.className = v; else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else if (v != null && v !== false) n.setAttribute(k, v === true ? "" : v);
    }
    kids.flat().forEach((c) => c != null && n.append(c.nodeType ? c : document.createTextNode(c)));
    return n;
  }
  const btn = (l, f, c) => h("button", { class: "btn small " + (c || ""), type: "button", onclick: f }, l);
  const commit = () => { save("tfw_posts", posts); save("tfw_reqs", reqs); save("tfw_saved", saved); render(); };
  const mine = (p) => p.author === me || p.mine;
  const accepted = (p) => reqs.filter((r) => r.postId === p.id && r.status === "accepted").length;
  const myReq = (p) => reqs.find((r) => r.postId === p.id && r.mine);
  const safeLink = (u) => /^https?:\/\//i.test(u || "");

  // ---------- Browse ----------
  function card(p) {
    const own = mine(p), req = myReq(p), open = p.vis === "public" || own || (req && req.status === "accepted");
    const c = h("div", { class: "card" }, h("span", { class: "badge" + (p.vis === "one" ? " one" : "") }, p.vis === "public" ? "Public" : "1-to-1"),
      h("h3", {}, p.title), h("p", { class: "meta" }, `${own ? "You" : p.author} · ${leaf(p.topic)}`));
    if (open) {
      c.append(h("p", {}, p.body));
      if (safeLink(p.link)) c.append(h("a", { href: p.link, target: "_blank", rel: "noopener noreferrer" }, "Open the resource"));
    } else c.append(h("div", { class: "lock" }, "🔒 Shared one-on-one. Ask for access and the author decides."));
    const row = h("div", { class: "row" });
    if (!own && p.vis === "public") row.append(btn(saved.includes(p.id) ? "Saved ✓" : "Save", () => { saved = saved.includes(p.id) ? saved.filter((x) => x !== p.id) : saved.concat(p.id); commit(); }, "soft"));
    if (!own && p.vis === "one") {
      if (!req) row.append(accepted(p) >= p.cap && p.cap ? h("span", { class: "meta" }, "Full right now") : btn("Request 1-to-1", () => { reqs.push({ id: "r" + Date.now(), postId: p.id, mine: true, name: me, status: "pending" }); commit(); }));
      else if (req.status === "pending") row.append(h("span", { class: "meta" }, "Requested, waiting for reply"), btn("Demo: author accepts", () => { req.status = "accepted"; commit(); }, "soft"));
      else row.append(h("span", { class: "meta" }, "✓ Access granted"));
    }
    return c.appendChild(row) && c;
  }
  function renderBrowse() {
    const search = h("input", { type: "search", placeholder: "Search by topic or title", "aria-label": "Search", value: q, oninput: (e) => { q = e.target.value; list(); } });
    const sel = h("select", { "aria-label": "Topic area", onchange: (e) => { fc = e.target.value; list(); } }, h("option", { value: "" }, "All topics"),
      CATS.map((c) => h("option", { value: c, selected: c === fc }, c)));
    const grid = h("div", { class: "grid" });
    function list() {
      const f = posts.filter((p) => (!fc || cat(p.topic) === fc) && (p.title + p.topic + p.author).toLowerCase().includes(q.toLowerCase()));
      grid.replaceChildren(...(f.length ? f.map(card) : [h("p", { class: "empty" }, "Nothing matches yet. Try another topic, or share the first one.")]));
    }
    list();
    return [h("h2", {}, "What members are sharing"), h("p", { class: "sub" }, "Public posts are open to read. 1-to-1 posts need a quick request."), h("div", { class: "filters" }, search, sel), grid];
  }

  // ---------- Share ----------
  function renderShare() {
    const err = h("p", { class: "err", role: "alert" }), cap = h("input", { type: "number", min: 1, max: 10, value: 2, id: "cap" });
    const capRow = h("label", { for: "cap", style: "display:none" }, "How many people can you work with at once?", cap);
    const title = h("input", { id: "t", maxlength: 90 }), body = h("textarea", { id: "b" }), link = h("input", { id: "l", type: "url", placeholder: "https://…" });
    const topic = h("select", { id: "tp" }, h("option", { value: "" }, "Choose a topic"), CATS.map((c) => h("optgroup", { label: c }, ALL.filter((t) => cat(t) === c).map((t) => h("option", { value: t }, t.split(" › ").slice(1).join(" › "))))));
    const radio = (v, label, hint, on) => h("label", { class: "opt" }, h("input", { type: "radio", name: "vis", value: v, checked: on, onchange: () => { capRow.style.display = v === "one" ? "grid" : "none"; } }), h("span", {}, h("b", {}, label), h("br"), hint));
    const form = h("form", { class: "form", novalidate: true, onsubmit: (e) => {
      e.preventDefault();
      const vis = form.querySelector("input[name=vis]:checked").value;
      if (!title.value.trim() || !topic.value || body.value.trim().split(/\s+/).length < 8) { err.textContent = "Add a title, pick a topic, and write at least 8 words about what you're sharing."; return; }
      if (link.value && !safeLink(link.value)) { err.textContent = "Links must start with http:// or https://."; return; }
      posts.unshift({ id: "p" + Date.now(), author: me, mine: true, title: title.value.trim(), topic: topic.value, body: body.value.trim(), link: link.value.trim(), vis, cap: vis === "one" ? Math.max(1, Number(cap.value) || 1) : 0 });
      toast = "Shared. It's now in your library."; location.hash = "library"; commit();
    } },
      h("label", { for: "t" }, "Title", title), h("label", { for: "tp" }, "Topic", topic),
      h("label", { for: "b" }, "What are you sharing?", body), h("label", { for: "l" }, "Link to a file or page (optional)", link),
      h("fieldset", {}, h("legend", {}, "Who can see it?"),
        radio("public", "Public", "Anyone on the platform can read it.", true),
        radio("one", "One-on-one only", "People see the title and ask you for access. You choose who gets it.", false), capRow),
      err, h("div", { class: "row" }, h("button", { class: "btn", type: "submit" }, "Share it")));
    return [h("h2", {}, "Share what you know"), h("p", { class: "sub" }, "You don't need to be a mentor to share. Skilled in something? Add it. You can still browse and learn anything else."), form];
  }

  // ---------- Library ----------
  function renderLibrary() {
    const out = [];
    if (toast) { out.push(h("div", { class: "toast", role: "status" }, toast)); toast = ""; }
    const own = posts.filter(mine);
    out.push(h("h2", {}, "My library"), h("p", { class: "sub" }, "Everything you've shared, who's asked for it, and what you've saved."));
    if (!own.length) out.push(h("p", { class: "empty" }, "You haven't shared anything yet. Whatever you know, someone here can use it."));
    own.forEach((p) => {
      const inc = reqs.filter((r) => r.postId === p.id && !r.mine);
      const vis = h("select", { "aria-label": "Visibility", onchange: (e) => { p.vis = e.target.value; p.cap = p.vis === "one" ? (p.cap || 2) : 0; commit(); } },
        h("option", { value: "public", selected: p.vis === "public" }, "Public"), h("option", { value: "one", selected: p.vis === "one" }, "One-on-one only"));
      const c = h("div", { class: "card" }, h("span", { class: "badge" + (p.vis === "one" ? " one" : "") }, p.vis === "public" ? "Public" : "1-to-1"), h("h3", {}, p.title), h("p", { class: "meta" }, leaf(p.topic)),
        h("div", { class: "row" }, vis, btn("Delete", () => { posts = posts.filter((x) => x.id !== p.id); reqs = reqs.filter((r) => r.postId !== p.id); commit(); }, "soft")));
      if (p.vis === "one") {
        c.append(h("p", { class: "meta" }, `${accepted(p)} of ${p.cap} spots filled`));
        inc.forEach((r) => c.append(h("div", { class: "row" }, h("span", {}, `${r.name} asked for access`), r.status === "pending" ? btn("Accept", () => { if (accepted(p) >= p.cap) { toast = "You're at your limit."; return commit(); } r.status = "accepted"; commit(); }) : h("span", { class: "meta" }, "✓ Accepted"))));
        c.append(btn("Demo: simulate a request", () => { reqs.push({ id: "r" + Date.now(), postId: p.id, mine: false, name: "Sam M.", status: "pending" }); commit(); }, "soft"));
      }
      out.push(c);
    });
    const sv = posts.filter((p) => saved.includes(p.id));
    out.push(h("h2", { style: "margin-top:34px" }, "Saved by me"));
    out.push(sv.length ? h("div", { class: "grid" }, sv.map(card)) : h("p", { class: "empty" }, "Nothing saved yet. Tap Save on any public post."));
    return out;
  }

  function render() {
    const t = ["browse", "share", "library"].includes(location.hash.slice(1)) ? location.hash.slice(1) : "browse";
    ["browse", "share", "library"].forEach((k) => { document.getElementById("t-" + k).classList.toggle("on", k === t); document.getElementById("n-" + k).classList.toggle("on", k === t); });
    view.replaceChildren(...({ browse: renderBrowse, share: renderShare, library: renderLibrary })[t]());
  }
  window.addEventListener("hashchange", render); render();
})();
